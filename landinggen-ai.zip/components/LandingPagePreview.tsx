
import React from 'react';
import { LandingPageData } from '../types';
import IconRenderer from './IconRenderer';

interface LandingPagePreviewProps {
  data: LandingPageData;
  productImage: string | null;
}

const LandingPagePreview: React.FC<LandingPagePreviewProps> = ({ data, productImage }) => {
  const primaryColor = data.config.primaryColor || 'blue-600';
  const primaryBg = `bg-${primaryColor}`;
  const primaryText = `text-${primaryColor}`;
  const primaryBorder = `border-${primaryColor}`;

  return (
    <div className="bg-white min-h-screen font-cairo overflow-y-auto">
      {/* Header */}
      <header className="py-4 px-6 md:px-12 flex justify-between items-center border-b sticky top-0 bg-white/95 backdrop-blur z-50">
        <div className={`text-2xl font-bold ${primaryText}`}>{data.header.logoText}</div>
        <nav className="hidden md:flex space-x-reverse space-x-6 text-gray-600">
          {data.header.navLinks.map((link, idx) => (
            <a key={idx} href="#" className="hover:text-black transition-colors">{link}</a>
          ))}
        </nav>
        <button className={`${primaryBg} text-white px-5 py-2 rounded-full font-medium hover:opacity-90 transition-all`}>
          ابدأ الآن
        </button>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-6 md:px-12 grid md:grid-cols-2 gap-12 items-center">
        <div className="order-2 md:order-1">
          <h1 className="text-4xl md:text-6xl font-black leading-tight mb-6">
            {data.hero.headline}
          </h1>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            {data.hero.subheadline}
          </p>
          <div className="flex flex-wrap gap-4 mb-8">
            {data.hero.benefits.map((benefit, idx) => (
              <div key={idx} className="flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-lg text-sm font-medium">
                <span className={`${primaryText}`}>✓</span> {benefit}
              </div>
            ))}
          </div>
          <button className={`${primaryBg} text-white text-lg px-8 py-4 rounded-xl font-bold shadow-xl shadow-${primaryColor}/20 hover:scale-105 transition-transform`}>
            {data.hero.ctaText}
          </button>
        </div>
        <div className="order-1 md:order-2 flex justify-center">
          {productImage ? (
            <div className="relative">
              <div className={`absolute -inset-4 ${primaryBg}/10 rounded-3xl blur-2xl`}></div>
              <img 
                src={productImage} 
                alt="Product" 
                className="relative z-10 w-full max-w-md h-auto rounded-3xl shadow-2xl object-cover transform rotate-2 hover:rotate-0 transition-transform duration-500"
              />
            </div>
          ) : (
            <div className="w-full h-80 bg-gray-200 rounded-3xl flex items-center justify-center text-gray-400">
              صورة المنتج هنا
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{data.about.title}</h2>
          <p className="text-gray-600 leading-relaxed">{data.about.content}</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {data.features.map((feature, idx) => (
            <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-14 h-14 ${primaryBg}/10 flex items-center justify-center rounded-xl mb-6`}>
                <IconRenderer name={feature.icon} className={`w-8 h-8 ${primaryText}`} />
              </div>
              <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-6 md:px-12">
        <div className="max-w-xl mx-auto bg-white border-2 border-gray-100 p-8 md:p-12 rounded-[2rem] shadow-xl text-center relative overflow-hidden">
          <div className={`absolute top-0 right-0 left-0 h-2 ${primaryBg}`}></div>
          <h2 className="text-2xl font-bold mb-2">{data.pricing.title}</h2>
          <div className="flex items-center justify-center gap-2 mb-8 mt-4">
            <span className="text-5xl font-black">{data.pricing.price}</span>
          </div>
          <ul className="space-y-4 mb-10 text-right">
            {data.pricing.features.map((f, i) => (
              <li key={i} className="flex items-center gap-3 text-gray-700">
                <IconRenderer name="CheckCircle2" className={`w-5 h-5 ${primaryText}`} />
                {f}
              </li>
            ))}
          </ul>
          <button className={`w-full ${primaryBg} text-white py-4 rounded-xl font-bold text-lg hover:opacity-90 transition-all`}>
            {data.pricing.cta}
          </button>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-900 text-white px-6 md:px-12">
        <h2 className="text-3xl font-bold text-center mb-16">ماذا يقول عملاؤنا؟</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {data.testimonials.map((t, i) => (
            <div key={i} className="bg-gray-800 p-8 rounded-2xl border border-gray-700">
              <p className="text-gray-300 italic mb-8 leading-relaxed">"{t.text}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gray-700 flex items-center justify-center font-bold">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold">{t.name}</h4>
                  <p className="text-sm text-gray-500">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-6 md:px-12 max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">الأسئلة الشائعة</h2>
        <div className="space-y-4">
          {data.faq.map((item, i) => (
            <div key={i} className="border border-gray-100 rounded-xl p-6 hover:bg-gray-50 transition-colors">
              <h3 className="font-bold text-lg mb-2 flex items-center gap-2">
                <span className={`${primaryText}`}>?</span>
                {item.question}
              </h3>
              <p className="text-gray-600 pr-5">{item.answer}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t px-6 md:px-12 bg-white">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className={`text-2xl font-bold ${primaryText}`}>{data.header.logoText}</div>
          <p className="text-gray-500">{data.footer.copyright}</p>
          <div className="flex gap-4">
            {data.footer.socialLinks.map((s, i) => (
              <span key={i} className="text-gray-400 hover:text-black cursor-pointer">{s}</span>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPagePreview;

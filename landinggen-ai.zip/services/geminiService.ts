
import { GoogleGenAI, Type } from "@google/genai";
import { LandingPageData, ProductAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeProductImage = async (base64Image: string): Promise<ProductAnalysis> => {
  const model = 'gemini-3-flash-preview';
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image.split(',')[1] || base64Image,
          },
        },
        {
          text: `حلل هذه الصورة لمنتج وقدم المعلومات التالية باللغة العربية بتنسيق JSON:
          - اسم المنتج (name)
          - فئة المنتج (category)
          - وصف جذاب (description)
          - أهم 3 فوائد للمنتج (mainBenefits)
          - الجمهور المستهدف (targetAudience)
          - نبرة الصوت المناسبة للتسويق (tone)`,
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          category: { type: Type.STRING },
          description: { type: Type.STRING },
          mainBenefits: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          targetAudience: { type: Type.STRING },
          tone: { type: Type.STRING }
        },
        required: ["name", "category", "description", "mainBenefits", "targetAudience", "tone"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const generateLandingPageContent = async (analysis: ProductAnalysis): Promise<LandingPageData> => {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `بناءً على تحليل المنتج التالي: ${JSON.stringify(analysis)}، أنشئ هيكل صفحة هبوط كاملة ومقنعة باللغة العربية.
  يجب أن يكون المحتوى تسويقياً واحترافياً.
  استخدم الألوان المناسبة للمنتج في الـ config.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          config: {
            type: Type.OBJECT,
            properties: {
              primaryColor: { type: Type.STRING, description: "Tailwind color class like 'blue-600'" },
              secondaryColor: { type: Type.STRING, description: "Tailwind color class like 'gray-100'" },
              fontFamily: { type: Type.STRING }
            },
            required: ["primaryColor", "secondaryColor"]
          },
          header: {
            type: Type.OBJECT,
            properties: {
              logoText: { type: Type.STRING },
              navLinks: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["logoText", "navLinks"]
          },
          hero: {
            type: Type.OBJECT,
            properties: {
              headline: { type: Type.STRING },
              subheadline: { type: Type.STRING },
              ctaText: { type: Type.STRING },
              benefits: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["headline", "subheadline", "ctaText"]
          },
          about: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING }
            },
            required: ["title", "content"]
          },
          features: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                icon: { type: Type.STRING, description: "Lucide icon name like 'Shield', 'Zap', 'Star'" }
              },
              required: ["title", "description", "icon"]
            }
          },
          testimonials: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                role: { type: Type.STRING },
                text: { type: Type.STRING },
                avatar: { type: Type.STRING }
              },
              required: ["name", "role", "text"]
            }
          },
          pricing: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              price: { type: Type.STRING },
              features: { type: Type.ARRAY, items: { type: Type.STRING } },
              cta: { type: Type.STRING }
            },
            required: ["title", "price", "features", "cta"]
          },
          faq: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                answer: { type: Type.STRING }
              },
              required: ["question", "answer"]
            }
          },
          footer: {
            type: Type.OBJECT,
            properties: {
              copyright: { type: Type.STRING },
              socialLinks: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["copyright"]
          }
        },
        required: ["config", "header", "hero", "about", "features", "testimonials", "pricing", "faq", "footer"]
      }
    }
  });

  return JSON.parse(response.text);
};


import React, { useState, useCallback, useRef } from 'react';
import { Upload, Image as ImageIcon, Sparkles, Wand2, ArrowLeft, Download, RotateCcw } from 'lucide-react';
import { analyzeProductImage, generateLandingPageContent } from './services/geminiService';
import { LandingPageData, ProductAnalysis } from './types';
import LandingPagePreview from './components/LandingPagePreview';

const App: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ProductAnalysis | null>(null);
  const [landingPage, setLandingPage] = useState<LandingPageData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'upload' | 'analyzing' | 'preview'>('upload');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generatePage = async () => {
    if (!image) return;
    
    setLoading(true);
    setError(null);
    setStep('analyzing');
    
    try {
      const productAnalysis = await analyzeProductImage(image);
      setAnalysis(productAnalysis);
      
      const pageData = await generateLandingPageContent(productAnalysis);
      setLandingPage(pageData);
      
      setStep('preview');
    } catch (err: any) {
      console.error(err);
      setError('حدث خطأ أثناء إنشاء الصفحة. يرجى المحاولة مرة أخرى.');
      setStep('upload');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setAnalysis(null);
    setLandingPage(null);
    setStep('upload');
  };

  return (
    <div className="min-h-screen bg-[#FDFDFD]">
      {/* Sidebar UI for generation control */}
      <div className={`fixed inset-y-0 right-0 w-full md:w-96 bg-white border-l shadow-2xl z-50 transform transition-transform duration-300 ${step === 'preview' ? 'translate-x-full md:translate-x-0' : 'translate-x-0'}`}>
        <div className="p-8 flex flex-col h-full">
          <div className="flex items-center gap-3 mb-12">
            <div className="bg-indigo-600 p-3 rounded-2xl text-white">
              <Sparkles size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-black text-gray-900 leading-tight">LandingGen AI</h1>
              <p className="text-xs text-gray-500 font-medium">مصمم صفحات الهبوط الذكي</p>
            </div>
          </div>

          <div className="flex-grow">
            {step === 'upload' && (
              <div className="space-y-6">
                <div className="bg-indigo-50 border-2 border-dashed border-indigo-200 rounded-3xl p-8 text-center">
                  {image ? (
                    <div className="relative group">
                      <img src={image} className="w-full h-48 object-cover rounded-2xl shadow-lg" alt="Selected" />
                      <button 
                        onClick={() => setImage(null)}
                        className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <RotateCcw size={16} />
                      </button>
                    </div>
                  ) : (
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="cursor-pointer space-y-4"
                    >
                      <div className="mx-auto w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-md text-indigo-600">
                        <Upload size={32} />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">ارفع صورة المنتج</p>
                        <p className="text-sm text-gray-500">أو اسحبها هنا للبدء</p>
                      </div>
                    </div>
                  )}
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileChange}
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="font-bold text-gray-800 flex items-center gap-2">
                    <Wand2 size={18} className="text-indigo-600" />
                    ماذا سيحدث؟
                  </h3>
                  <ul className="text-sm text-gray-600 space-y-3 pr-4 border-r-2 border-indigo-100">
                    <li>1. سيقوم الذكاء الاصطناعي بتحليل تفاصيل منتجك.</li>
                    <li>2. سيتم كتابة نصوص تسويقية مقنعة واحترافية.</li>
                    <li>3. سيتم تصميم صفحة هبوط متكاملة بلمح البصر.</li>
                  </ul>
                </div>
              </div>
            )}

            {step === 'analyzing' && (
              <div className="flex flex-col items-center justify-center h-64 space-y-6 text-center">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
                  <Sparkles className="absolute inset-0 m-auto text-indigo-600 animate-pulse" size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">جاري التحليل والتصميم...</h2>
                  <p className="text-gray-500 mt-2">نقوم الآن بدراسة منتجك لصنع أفضل صفحة هبوط ممكنة</p>
                </div>
              </div>
            )}

            {step === 'preview' && analysis && (
              <div className="space-y-8 animate-in slide-in-from-right duration-500">
                <div className="bg-green-50 p-6 rounded-3xl border border-green-100">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="bg-green-500 text-white p-2 rounded-full">
                      <ImageIcon size={16} />
                    </div>
                    <h3 className="font-bold text-green-900">تم تحليل المنتج بنجاح</h3>
                  </div>
                  <p className="text-sm text-green-800 font-bold mb-1">{analysis.name}</p>
                  <p className="text-xs text-green-700 leading-relaxed">{analysis.description}</p>
                </div>

                <div className="space-y-4">
                  <button 
                    onClick={() => window.print()}
                    className="w-full flex items-center justify-center gap-3 bg-gray-900 text-white py-4 rounded-2xl font-bold hover:bg-black transition-all shadow-lg"
                  >
                    <Download size={20} />
                    تصدير الصفحة (PDF)
                  </button>
                  <button 
                    onClick={reset}
                    className="w-full flex items-center justify-center gap-3 bg-white border-2 border-gray-100 text-gray-600 py-4 rounded-2xl font-bold hover:bg-gray-50 transition-all"
                  >
                    <RotateCcw size={20} />
                    البدء من جديد
                  </button>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-6 p-4 bg-red-50 text-red-600 rounded-2xl text-sm font-medium border border-red-100">
                {error}
              </div>
            )}
          </div>

          {step === 'upload' && (
            <button 
              onClick={generatePage}
              disabled={!image || loading}
              className={`mt-8 w-full py-4 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 shadow-xl ${image && !loading ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200' : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}
            >
              انشر سحرك الآن
              <Sparkles size={20} />
            </button>
          )}
        </div>
      </div>

      {/* Main Preview Area */}
      <main className={`transition-all duration-300 ${step === 'preview' ? 'md:mr-96' : ''}`}>
        {step === 'preview' && landingPage ? (
          <div className="h-screen overflow-y-auto">
             {/* Device preview bar (optional aesthetic) */}
             <div className="bg-gray-100 p-2 border-b flex justify-center gap-4 sticky top-0 z-[60]">
                <div className="px-3 py-1 bg-white rounded-lg text-xs font-bold text-gray-400">Preview Desktop</div>
                <div className="px-3 py-1 bg-gray-200 rounded-lg text-xs font-bold text-gray-600 cursor-not-allowed">Mobile (Coming soon)</div>
             </div>
             <LandingPagePreview data={landingPage} productImage={image} />
          </div>
        ) : (
          <div className="h-screen flex items-center justify-center p-6 text-center">
            <div className="max-w-2xl">
              <div className="mb-8 inline-block bg-indigo-600/5 p-8 rounded-[3rem] animate-pulse">
                <Sparkles size={64} className="text-indigo-600" />
              </div>
              <h2 className="text-5xl font-black text-gray-900 mb-6 leading-tight">
                حوّل صورة منتجك إلى <span className="text-indigo-600">مبيعات حقيقية</span>
              </h2>
              <p className="text-xl text-gray-500 leading-relaxed mb-10">
                المنصة الأولى عربياً التي تستخدم الذكاء الاصطناعي لتحويل صورة المنتج إلى صفحة هبوط احترافية عالية التحويل في ثوانٍ معدودة.
              </p>
              <div className="grid grid-cols-3 gap-6">
                {[
                  { label: "تحليل ذكي", desc: "للصور والمميزات" },
                  { label: "كتابة إبداعية", desc: "لنصوص تسويقية" },
                  { label: "تصميم عصري", desc: "متوافق مع كل الأجهزة" }
                ].map((stat, i) => (
                  <div key={i} className="bg-white border border-gray-100 p-6 rounded-3xl shadow-sm">
                    <p className="font-black text-indigo-600 mb-1">{stat.label}</p>
                    <p className="text-xs text-gray-400 font-medium">{stat.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;


export interface Feature {
  title: string;
  description: string;
  icon: string;
}

export interface Testimonial {
  name: string;
  role: string;
  text: string;
  avatar: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface LandingPageData {
  config: {
    primaryColor: string;
    secondaryColor: string;
    fontFamily: string;
  };
  header: {
    logoText: string;
    navLinks: string[];
  };
  hero: {
    headline: string;
    subheadline: string;
    ctaText: string;
    benefits: string[];
  };
  about: {
    title: string;
    content: string;
  };
  features: Feature[];
  testimonials: Testimonial[];
  pricing: {
    title: string;
    price: string;
    features: string[];
    cta: string;
  };
  faq: FAQItem[];
  footer: {
    copyright: string;
    socialLinks: string[];
  };
}

export interface ProductAnalysis {
  name: string;
  category: string;
  description: string;
  mainBenefits: string[];
  targetAudience: string;
  tone: string;
}
